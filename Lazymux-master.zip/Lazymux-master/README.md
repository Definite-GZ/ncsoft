![Lazymux](https://raw.githubusercontent.com/Gameye98/Lazymux/master/core/lazymux.png)

# Lazymux

Simple tool and easy to use ^^
Recommended for the lazy users of Termux